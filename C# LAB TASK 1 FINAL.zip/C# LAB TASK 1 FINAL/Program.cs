using System;
using System.Windows.Forms;

namespace Login_and_Register
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Changed from Application.Run(new frmRegister());
            // so the program opens on the login screen, not the signup screen.
            Application.Run(new frmLogin());
        }
    }
}

using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Login_and_Register
{
    public partial class frmLogin : Form
    {
        // Replaces the three OleDb field declarations (OleDbConnection,
        // OleDbCommand, OleDbDataAdapter) that used to point at db_users.mdb.
        private static string myConn =
            ConfigurationManager.ConnectionStrings["connString"].ConnectionString;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text.Trim() == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(myConn))
                {
                    con.Open();

                    string login = "SELECT COUNT(*) FROM tbl_users WHERE username = @username AND password = @password";

                    using (SqlCommand cmd = new SqlCommand(login, con))
                    {
                        cmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        if (count == 1)
                        {
                            new frmDashboard().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Wrong username or password, please try again.",
                                "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtUsername.Text = "";
                            txtPassword.Text = "";
                            txtUsername.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n\n" + ex.Message);
            }
        }

        // ------------------------------------------------------------------
        // TODO: paste your EXISTING handlers back in here, unchanged.
        // The lab does not touch these - they don't talk to the database:
        //
        //   private void chkShowPassword_CheckedChanged(object sender, EventArgs e) { ... }
        //   private void btnClear_Click(object sender, EventArgs e) { ... }
        //   private void btnClose_Click(object sender, EventArgs e) { ... }
        //   (plus any Register-link click handler that opens frmRegister)
        //
        // Copy these straight from your original frmLogin.cs - do not
        // delete them, only the OleDb fields and btnLogin_Click changed.
        // ------------------------------------------------------------------
    }
}

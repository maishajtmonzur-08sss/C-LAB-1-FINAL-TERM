-- database.sql
-- Run this in SQL Server Management Studio (or SQL Server Object Explorer
-- inside Visual Studio) before running the application.

CREATE DATABASE db_users;
GO

USE db_users;
GO

CREATE TABLE tbl_users (
    id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) NOT NULL UNIQUE,
    password NVARCHAR(100) NOT NULL
);
GO

-- one test account so you can log in before you register anybody
INSERT INTO tbl_users (username, password) VALUES ('admin', 'admin123');
GO

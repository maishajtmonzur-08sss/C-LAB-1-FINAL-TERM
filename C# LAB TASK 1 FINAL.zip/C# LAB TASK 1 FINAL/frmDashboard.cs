using System;
using System.Windows.Forms;

namespace Login_and_Register
{
    public partial class frmDashboard : Form
    {
        public frmDashboard()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                new frmLogin().Show();
                this.Close();
            }
        }

        // ------------------------------------------------------------------
        // TODO: paste your EXISTING handlers back in here, unchanged.
        // Only btnLogout_Click changed - the old version called
        // Application.Exit() and showed "Goodbye Sayan", which quit the
        // whole program instead of returning to the login screen.
        // ------------------------------------------------------------------
    }
}
